package hr.fer.oop.password;

import java.util.Scanner;

import hr.fer.oop.password.gen.PasswordGeneratorZad1;

public class MainZad1 {

	public static void main(String[] args) {
		
		if (args.length != 1) {
			System.out.println("Prihvacam jedan argument!");
			return;
		}
		
		String moguciZnakovi = args[0];
		
		PasswordGeneratorZad1 generator = new PasswordGeneratorZad1(moguciZnakovi);
		Scanner sc = new Scanner(System.in);
		System.out.println("Upisuj velicine lozinki dok ne upises 'q' ili 'quit'");
		while(sc.hasNext()) {
			String line = sc.nextLine();
			if ("quit".equals(line) || "q".equals(line)) {
				System.out.println("Gotovo!");
				break;
			}
			int velicinaLozinke = Integer.parseInt(line.trim());
			String lozinka = generator.generirajSlucajnuLozinku(velicinaLozinke);
			System.out.println("Novo generirana lozinka: " + lozinka);
		}
		sc.close();

	}

}
