package hr.fer.oop.password.util;

public class ArrayUtil {
	
	public static int sum(int[] values) {
		int sum = 0;
		for (int value : values) {
			sum += value;
		}
		return sum;
	}

	public static int[] arrange(int endValue) {
		int[] moguciIndeksi = new int[endValue];
		for (int i = 0; i < endValue; ++i) {
			moguciIndeksi[i] = i;
		}
		return moguciIndeksi;
	}

	public static void swap(int[] arr, int indexA, int indexB) {
		int temp = arr[indexA];
		arr[indexA] = arr[indexB];
		arr[indexB] = temp;
	}

	public static void shuffle(char[] lozinka) {
		for(int i = lozinka.length; i > 0; --i) {
			int indeksZnaka = RandomUtil.slucajanDo(i);
			swap(lozinka, indeksZnaka, i - 1);
		}
	}

	public static void swap(char[] arr, int indexA, int indexB) {
		char temp = arr[indexA];
		arr[indexA] = arr[indexB];
		arr[indexB] = temp;
	}

}
