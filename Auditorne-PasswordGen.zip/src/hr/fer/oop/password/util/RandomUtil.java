package hr.fer.oop.password.util;

public class RandomUtil {

	public static int slucajanDo(int n) {
		return (int)(Math.random() * n);
	}

}
