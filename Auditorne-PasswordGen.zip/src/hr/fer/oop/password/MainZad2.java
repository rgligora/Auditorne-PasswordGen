package hr.fer.oop.password;

import java.util.Scanner;

import hr.fer.oop.password.gen.PasswordGeneratorZad2;

public class MainZad2 {

	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("Prihvacam barem jedan argument!");
			return;
		}
		
		PasswordGeneratorZad2 generator = new PasswordGeneratorZad2(args);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Skupovi su: " + String.join(", ", args));
		System.out.println("Upisuj velicine skupova dok ne upises 'quit' ili 'q'");
		int[] brojPoSkupu = new int[args.length];
		while(sc.hasNext()) {
			String line = sc.nextLine();
			if ("quit".equals(line) || "q".equals(line)) {
				System.out.println("Gotovo!");
				break;
			}
			String[] velicine = line.trim().split(" ");
			if (velicine.length != brojPoSkupu.length) {
				System.out.println("Krivi broj argumenata, ignoriram!");
				continue;
			}
			for(int i = 0, n = velicine.length; i < n; ++i) {
				brojPoSkupu[i] = Integer.parseInt(velicine[i]);
			}
			String lozinka = generator.generirajSlucajnuLozinku(brojPoSkupu);
			System.out.println("Novo generirana lozinka: " + lozinka);
		}
		sc.close();
	}

}
