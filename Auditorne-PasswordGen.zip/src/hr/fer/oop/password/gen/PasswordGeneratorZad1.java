package hr.fer.oop.password.gen;

import hr.fer.oop.password.util.RandomUtil;

public class PasswordGeneratorZad1 {

	private String moguciZnakovi;

	public PasswordGeneratorZad1(String moguciZnakovi) {
		this.moguciZnakovi = moguciZnakovi;
	}

	public String generirajSlucajnuLozinku(int velicinaLozinke) {
		char[] lozinka = new char[velicinaLozinke];
		for(int i = 0; i < velicinaLozinke; ++i) {
			int indexZnaka = RandomUtil.slucajanDo(moguciZnakovi.length());
			lozinka[i] = moguciZnakovi.charAt(indexZnaka);
		}
		return String.valueOf(lozinka);
	}

}
