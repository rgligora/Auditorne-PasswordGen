package hr.fer.oop.password.gen;

import hr.fer.oop.password.util.ArrayUtil;
import hr.fer.oop.password.util.RandomUtil;

public class PasswordGeneratorZad2 {

	private String[] skupoviZnakova;

	public PasswordGeneratorZad2(String[] skupoviZnakova) {
		this.skupoviZnakova = skupoviZnakova;
	}

	public String generirajSlucajnuLozinku(int[] znakovaPoSkupu) {
		int velicinaLozinke = ArrayUtil.sum(znakovaPoSkupu);
		char[] lozinka = new char[velicinaLozinke];
		int indeksULozinci = 0;
		for (int i = 0; i < znakovaPoSkupu.length; ++i) {
			int nZnakova = znakovaPoSkupu[i];
			String skupZnakova = skupoviZnakova[i];
			for (int j = 0; j < nZnakova; ++j) {
				int indeksUSkupu = RandomUtil.slucajanDo(skupZnakova.length());
				lozinka[indeksULozinci] = skupZnakova.charAt(indeksUSkupu);
				++indeksULozinci;
			}
		}
		ArrayUtil.shuffle(lozinka);
		return String.valueOf(lozinka);
	}
}
